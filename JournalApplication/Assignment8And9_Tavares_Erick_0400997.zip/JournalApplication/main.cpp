//Name: Erick Tavares
//Date: 25/08/2017
//Description: Console app that allows you to create journals, add some entries and save as a text file.


#include <iostream>
#include "JournalApp.h"


using namespace std;


int main()
{
	JournalApp app = JournalApp();
	app.Run();
	return 0;
}
